<?php

// Heading
$_['heading_title']     = 'Service Booking';

// Messages
$_['msg_nopost']        = 'Please enter a order number';
$_['msg_notfound']      = 'We could not find an order with given number';
$_['msg_Angemeldet']    = 'The service has been booked. But the bike is not in our store yet.';
$_['msg_Im_Haus']       = 'The bike is in our store.';
$_['msg_Werkstatt']     = 'The bike is in our store.';
$_['msg_Fertig']        = 'The bike is serviced and can be picked up.';