<?php

// Heading
$_['heading_title']     = 'Service Booking';

// Messages
$_['msg_nopost']        = 'Bitte eine Bearbeitungsnummer angeben – Danke!';
$_['msg_notfound']      = 'Äh, wir konnten keine Service-Buchung mit der angegebenen Bearbeitungsnummer finden – bitte nochmal die Eingabe prüfen!';
$_['msg_Angemeldet']    = 'Der Service wurde über die Webseite gebucht, das Rad ist aber noch nicht im Laden abgegeben worden.';
$_['msg_Im_Haus']       = 'Das Rad ist hier in der Werkstatt und wird gerade bearbeitet.';
$_['msg_Werkstatt']     = 'Das Rad ist hier in der Werkstatt und wird gerade bearbeitet.';
$_['msg_Fertig']        = 'Das Rad ist fertig und kann abgeholt werden.';